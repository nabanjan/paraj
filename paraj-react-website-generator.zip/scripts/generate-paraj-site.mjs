
import fs from "node:fs";
import OpenAI from "openai";

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

async function run(){

const prompt = `Generate a beautiful one-screen React landing page for
Paraj Express Services (logistics company in Assam India).

Requirements:

- Hero section
- Services
- Coverage in Assam
- Quote form UI
- Shipment tracking UI placeholder
- Floating WhatsApp button using number 919864096534
- Modern gradients, clean typography, responsive layout

Return JSON with keys:
app_jsx
app_css
`

const res = await client.responses.create({
  model: "gpt-5.2-codex",
  input: prompt
})

const text = res.output_text || ""
const data = JSON.parse(text)

fs.writeFileSync("src/App.jsx", data.app_jsx)
fs.writeFileSync("src/App.css", data.app_css)

console.log("Website generated.")
}

run()
