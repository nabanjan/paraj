
# Paraj Express Services – React Website Generator

This project generates a **beautiful one‑screen React website** for Paraj Express Services
using the OpenAI Codex API during build time.

The generated website is **fully static** and requires **no backend**.

---

## Important Architecture Rule

OpenAI API calls must ONLY occur in the generator script.

Do NOT call OpenAI APIs from React frontend code.

Correct flow:

Internet Data
      ↓
OpenAI Generator Script
      ↓
Generated React UI
      ↓
Static Website Deployment

Why?

React runs in the user's browser. If the OpenAI API were called there,
your API key would be publicly visible.

Therefore:

✔ Allowed
scripts/generate-paraj-site.mjs

❌ Not allowed
src/App.jsx
src/main.jsx

---

## Setup

Install dependencies

npm install

Set OpenAI key

Mac/Linux
export OPENAI_API_KEY="your_key_here"

Windows
setx OPENAI_API_KEY "your_key_here"

---

## Generate Website

node scripts/generate-paraj-site.mjs

This generates

src/App.jsx
src/App.css

---

## Run Website

npm run dev

Open

http://localhost:5173

---

## WhatsApp Contact

Configured for:

+91‑9864096534

WhatsApp link used in UI:

https://wa.me/919864096534

---

## Deployment

Because the site is static it can be deployed easily:

Vercel
Netlify
GitHub Pages

Example URL

https://paraj-express.vercel.app

---

## Future Improvements

• Real shipment tracking backend
• Admin dashboard
• Pricing calculator
• Google Maps location
• SEO landing pages
