
export default function App() {
  return (
    <div style={{fontFamily:"Arial",padding:40}}>
      <h1>Paraj Express Services</h1>
      <p>Express Delivery • Courier • Logistics • Assam</p>
      <a href="https://wa.me/919864096534">Chat on WhatsApp</a>
    </div>
  );
}
